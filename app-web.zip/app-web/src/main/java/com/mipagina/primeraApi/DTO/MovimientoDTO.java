package com.mipagina.primeraApi.DTO;

import com.mipagina.primeraApi.models.MovimientoEntidad.TipoMovimiento;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class MovimientoDTO {
    
    public MovimientoDTO() {}

    public MovimientoDTO(Long productoId, Integer cantidad, TipoMovimiento tipo, 
                        Long proveedorId, String motivo, String observacion) {
        this.productoId = productoId;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.proveedorId = proveedorId;
        this.motivo = motivo;
        this.observacion = observacion;
    }

    @NotNull(message = "El ID del producto es obligatorio.")
    private Long productoId;

    @NotNull(message = "La cantidad es obligatoria.")
    @Positive(message = "La cantidad debe ser positiva.")
    private Integer cantidad;

    @NotNull(message = "El tipo de movimiento es obligatorio.")
    private TipoMovimiento tipo;

    private Long proveedorId;

    private String motivo;

    private String observacion;

    // Getters y Setters
    public Long getProductoId() {
        return productoId;
    }

    public void setProductoId(Long productoId) {
        this.productoId = productoId;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public TipoMovimiento getTipo() {
        return tipo;
    }

    public void setTipo(TipoMovimiento tipo) {
        this.tipo = tipo;
    }

    public Long getProveedorId() {
        return proveedorId;
    }

    public void setProveedorId(Long proveedorId) {
        this.proveedorId = proveedorId;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
}