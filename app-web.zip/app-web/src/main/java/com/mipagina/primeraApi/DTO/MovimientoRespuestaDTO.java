package com.mipagina.primeraApi.DTO;

import java.time.LocalDateTime;

public class MovimientoRespuestaDTO {

    private Long id;
    private String tipo;
    private Integer cantidad;
    private LocalDateTime fecha;
    private String motivo;
    private String observacion;
    private Long productoId;
    private String productoNombre;
    private Long proveedorId;
    private String proveedorNombre;

    public MovimientoRespuestaDTO() {}

    public MovimientoRespuestaDTO(Long id, String tipo, Integer cantidad, LocalDateTime fecha,
                                   String motivo, String observacion,
                                   Long productoId, String productoNombre,
                                   Long proveedorId, String proveedorNombre) {
        this.id = id;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.fecha = fecha;
        this.motivo = motivo;
        this.observacion = observacion;
        this.productoId = productoId;
        this.productoNombre = productoNombre;
        this.proveedorId = proveedorId;
        this.proveedorNombre = proveedorNombre;
    }

    // Getters y Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public String getObservacion() { return observacion; }
    public void setObservacion(String observacion) { this.observacion = observacion; }

    public Long getProductoId() { return productoId; }
    public void setProductoId(Long productoId) { this.productoId = productoId; }

    public String getProductoNombre() { return productoNombre; }
    public void setProductoNombre(String productoNombre) { this.productoNombre = productoNombre; }

    public Long getProveedorId() { return proveedorId; }
    public void setProveedorId(Long proveedorId) { this.proveedorId = proveedorId; }

    public String getProveedorNombre() { return proveedorNombre; }
    public void setProveedorNombre(String proveedorNombre) { this.proveedorNombre = proveedorNombre; }
}
