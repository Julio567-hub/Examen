package com.mipagina.primeraApi.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class ProductoDTO {
    public ProductoDTO() {}

    public ProductoDTO(String nombre, String categoria, Float precio, String proveedor, Integer stockActual, Integer stockMinimo) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.proveedor = proveedor;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
    }

    @NotBlank(message = "El nombre del producto es obligatorio.")
    private String nombre;

    private String descripcion;

    @NotBlank(message = "La categoría es obligatoria.")
    private String categoria;

    @NotBlank(message = "El proveedor es obligatorio.")
    private String proveedor;

    @NotNull(message = "El precio es obligatorio.")
    @Positive(message = "El precio debe ser mayor a 0.")
    private Float precio;

    @NotNull(message = "El stock actual es obligatorio.")
    private Integer stockActual;

    @NotNull(message = "El stock mínimo es obligatorio.")
    private Integer stockMinimo;

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    public Float getPrecio() {
        return precio;
    }
    public void setPrecio(Float precio) {
        this.precio = precio;
    }
    public String getProveedor() {
        return proveedor;
    }
    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }
    public Integer getStockActual() {
        return stockActual;
    }
    public void setStockActual(Integer stockActual) {
        this.stockActual = stockActual;
    }
    public Integer getStockMinimo() {
        return stockMinimo;
    }
    public void setStockMinimo(Integer stockMinimo) {
        this.stockMinimo = stockMinimo;
    }
}