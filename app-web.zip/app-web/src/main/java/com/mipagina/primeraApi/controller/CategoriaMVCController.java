package com.mipagina.primeraApi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mipagina.primeraApi.models.CategoriaEntidad;
import com.mipagina.primeraApi.services.CategoriaServicio;
import com.mipagina.primeraApi.services.ProductoServicio;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/categorias")
public class CategoriaMVCController {

    private final CategoriaServicio categoriaServicio;
    private final ProductoServicio productoServicio;

    public CategoriaMVCController(CategoriaServicio categoriaServicio, ProductoServicio productoServicio) {
        this.categoriaServicio = categoriaServicio;
        this.productoServicio = productoServicio;
    }

    @GetMapping
    public String listarCategorias(Model model) {
        model.addAttribute("categorias", categoriaServicio.listarTodo());
        return "categorias/lista";
    }

    @GetMapping("/nueva")
    public String nuevaCategoria(Model model) {
        model.addAttribute("categoria", new CategoriaEntidad());
        model.addAttribute("isNew", true);
        return "categorias/formulario";
    }

    @PostMapping("/guardar")
    public String guardarCategoria(@Valid CategoriaEntidad categoria, Model model, RedirectAttributes redirectAttrs) {
        try {
            categoriaServicio.guardarCategoria(categoria);
            redirectAttrs.addFlashAttribute("exito", "Categoría creada exitosamente.");
            return "redirect:/categorias";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("categoria", categoria);
            model.addAttribute("isNew", true);
            return "categorias/formulario";
        }
    }

    @GetMapping("/{id}/editar")
    public String editarCategoria(@PathVariable Long id, Model model) {
        categoriaServicio.buscarPorId(id).ifPresent(cat -> model.addAttribute("categoria", cat));
        model.addAttribute("isNew", false);
        return "categorias/formulario";
    }

    @PostMapping("/{id}/actualizar")
    public String actualizarCategoria(@PathVariable Long id, @Valid CategoriaEntidad categoria, Model model, RedirectAttributes redirectAttrs) {
        try {
            categoriaServicio.buscarPorId(id).ifPresent(cat -> {
                cat.setNombre(categoria.getNombre());
                cat.setDescripcion(categoria.getDescripcion());
                categoriaServicio.guardarCategoriaExistente(cat);
            });
            redirectAttrs.addFlashAttribute("exito", "Categoría actualizada exitosamente.");
            return "redirect:/categorias";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("categoria", categoria);
            model.addAttribute("isNew", false);
            return "categorias/formulario";
        }
    }

    @GetMapping("/{id}/eliminar")
    public String eliminarCategoria(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        try {
            categoriaServicio.buscarPorId(id).ifPresent(cat -> categoriaServicio.eliminarCategoria(cat));
            redirectAttrs.addFlashAttribute("exito", "Categoría eliminada exitosamente.");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("error", "No se puede eliminar: " + e.getMessage());
        }
        return "redirect:/categorias";
    }

    @GetMapping("/{id}/productos")
    public String productosPorCategoria(@PathVariable Long id, Model model) {
        categoriaServicio.buscarPorId(id).ifPresent(cat -> {
            model.addAttribute("categoria", cat);
            model.addAttribute("productos", productoServicio.filtrarPorCategoria(cat));
        });
        return "categorias/productos";
    }
}
