package com.mipagina.primeraApi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.mipagina.primeraApi.services.CategoriaServicio;
import com.mipagina.primeraApi.services.MovimientoServicio;
import com.mipagina.primeraApi.services.ProductoServicio;
import com.mipagina.primeraApi.services.ProveedorServicio;

import java.time.LocalDateTime;

@Controller
public class HomeController {

    private final ProductoServicio productoServicio;
    private final ProveedorServicio proveedorServicio;
    private final MovimientoServicio movimientoServicio;
    private final CategoriaServicio categoriaServicio;

    public HomeController(ProductoServicio productoServicio, ProveedorServicio proveedorServicio,
                          MovimientoServicio movimientoServicio, CategoriaServicio categoriaServicio) {
        this.productoServicio = productoServicio;
        this.proveedorServicio = proveedorServicio;
        this.movimientoServicio = movimientoServicio;
        this.categoriaServicio = categoriaServicio;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        long totalProductos = productoServicio.listarTodo().size();
        long totalProveedores = proveedorServicio.listarTodos().size();
        long totalCategorias = categoriaServicio.listarTodo().size();
        long stockBajo = productoServicio.productosConStockBajo().size();

        LocalDateTime hoy = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0).withNano(0);
        long movimientosHoy = movimientoServicio.movimientosPorRangoFechas(hoy, LocalDateTime.now()).size();

        model.addAttribute("totalProductos", totalProductos);
        model.addAttribute("totalProveedores", totalProveedores);
        model.addAttribute("totalCategorias", totalCategorias);
        model.addAttribute("stockBajo", stockBajo);
        model.addAttribute("movimientosHoy", movimientosHoy);
        model.addAttribute("productosAlerta", productoServicio.productosConStockBajo());

        return "dashboard";
    }
}
