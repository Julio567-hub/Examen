package com.mipagina.primeraApi.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mipagina.primeraApi.DTO.MovimientoDTO;
import com.mipagina.primeraApi.DTO.MovimientoRespuestaDTO;
import com.mipagina.primeraApi.models.MovimientoEntidad.TipoMovimiento;
import com.mipagina.primeraApi.services.MovimientoServicio;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/inventario/movimientos")
public class MovimientoController {

    private final MovimientoServicio movimientoServicio;

    public MovimientoController(MovimientoServicio movimientoServicio) {
        this.movimientoServicio = movimientoServicio;
    }

    @GetMapping
    public ResponseEntity<List<MovimientoRespuestaDTO>> listarTodos() {
        return ResponseEntity.ok(movimientoServicio.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MovimientoRespuestaDTO> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(movimientoServicio.buscarPorId(id));
    }

    @PostMapping("/registrar")
    public ResponseEntity<MovimientoRespuestaDTO> registrarMovimiento(@Valid @RequestBody MovimientoDTO movimientoDTO) {
        return ResponseEntity.ok(movimientoServicio.registrarMovimiento(movimientoDTO));
    }

    @GetMapping("/producto/{productoId}")
    public ResponseEntity<List<MovimientoRespuestaDTO>> movimientosPorProducto(@PathVariable Long productoId) {
        return ResponseEntity.ok(movimientoServicio.movimientosPorProducto(productoId));
    }

    @GetMapping("/tipo/{tipo}")
    public ResponseEntity<List<MovimientoRespuestaDTO>> movimientosPorTipo(@PathVariable TipoMovimiento tipo) {
        return ResponseEntity.ok(movimientoServicio.movimientosPorTipo(tipo));
    }

    @GetMapping("/filtrar")
    public ResponseEntity<List<MovimientoRespuestaDTO>> filtrarMovimientos(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime fechaFin,
            @RequestParam(required = false) TipoMovimiento tipo,
            @RequestParam(required = false) Long productoId) {
        return ResponseEntity.ok(movimientoServicio.filtrarMovimientos(fechaInicio, fechaFin, tipo, productoId));
    }
}
