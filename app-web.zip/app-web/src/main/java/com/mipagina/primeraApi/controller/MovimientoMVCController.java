package com.mipagina.primeraApi.controller;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mipagina.primeraApi.DTO.MovimientoDTO;
import com.mipagina.primeraApi.models.MovimientoEntidad.TipoMovimiento;
import com.mipagina.primeraApi.services.MovimientoServicio;
import com.mipagina.primeraApi.services.ProductoServicio;
import com.mipagina.primeraApi.services.ProveedorServicio;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/movimientos")
public class MovimientoMVCController {

    private final MovimientoServicio movimientoServicio;
    private final ProductoServicio productoServicio;
    private final ProveedorServicio proveedorServicio;

    public MovimientoMVCController(MovimientoServicio movimientoServicio,
                                   ProductoServicio productoServicio,
                                   ProveedorServicio proveedorServicio) {
        this.movimientoServicio = movimientoServicio;
        this.productoServicio = productoServicio;
        this.proveedorServicio = proveedorServicio;
    }

    @GetMapping
    public String listarMovimientos(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin,
            @RequestParam(required = false) String tipo,
            @RequestParam(required = false) Long productoId,
            Model model) {

        LocalDateTime inicio = fechaInicio != null ? fechaInicio.atStartOfDay() : null;
        LocalDateTime fin    = fechaFin    != null ? fechaFin.atTime(23, 59, 59) : null;

        // Convierte el String del param a enum, o null si viene vacío
        TipoMovimiento tipoMovimiento = null;
        if (tipo != null && !tipo.isBlank()) {
            try {
                tipoMovimiento = TipoMovimiento.valueOf(tipo.toUpperCase());
            } catch (IllegalArgumentException ignored) {
                // valor inválido → se ignora el filtro de tipo
            }
        }

        boolean hayFiltros = inicio != null || fin != null || tipoMovimiento != null || productoId != null;

        if (hayFiltros) {
            model.addAttribute("movimientos", movimientoServicio.filtrarMovimientos(inicio, fin, tipoMovimiento, productoId));
        } else {
            model.addAttribute("movimientos", movimientoServicio.listarTodos());
        }

        model.addAttribute("productos", productoServicio.listarTodo());
        model.addAttribute("fechaInicio", fechaInicio);
        model.addAttribute("fechaFin", fechaFin);
        model.addAttribute("tipoFiltro", tipo);
        model.addAttribute("productoIdFiltro", productoId);
        return "movimientos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoMovimiento(Model model) {
        model.addAttribute("movimiento", new MovimientoDTO());
        model.addAttribute("productos", productoServicio.listarTodo());
        model.addAttribute("proveedores", proveedorServicio.listarTodos());
        return "movimientos/formulario";
    }

    @PostMapping("/registrar")
    public String registrarMovimiento(
            @Valid MovimientoDTO movimiento,
            BindingResult bindingResult,       // captura errores de @Valid
            Model model,
            RedirectAttributes redirectAttrs) {

        // Si hay errores de validación, volver al formulario mostrándolos
        if (bindingResult.hasErrors()) {
            model.addAttribute("movimiento", movimiento);
            model.addAttribute("productos", productoServicio.listarTodo());
            model.addAttribute("proveedores", proveedorServicio.listarTodos());
            return "movimientos/formulario";
        }

        try {
            movimientoServicio.registrarMovimiento(movimiento);
            redirectAttrs.addFlashAttribute("exito", "Movimiento registrado exitosamente.");
            return "redirect:/movimientos";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("movimiento", movimiento);
            model.addAttribute("productos", productoServicio.listarTodo());
            model.addAttribute("proveedores", proveedorServicio.listarTodos());
            return "movimientos/formulario";
        }
    }

    @GetMapping("/{id}")
    public String verMovimiento(@PathVariable Long id, Model model) {
        model.addAttribute("movimiento", movimientoServicio.buscarPorId(id));
        return "movimientos/detalle";
    }
}
