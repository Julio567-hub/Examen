package com.mipagina.primeraApi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mipagina.primeraApi.DTO.ProductoDTO;
import com.mipagina.primeraApi.services.CategoriaServicio;
import com.mipagina.primeraApi.services.ProductoServicio;
import com.mipagina.primeraApi.services.ProveedorServicio;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/productos")
public class ProductoMVCController {

    private final ProductoServicio productoServicio;
    private final CategoriaServicio categoriaServicio;
    private final ProveedorServicio proveedorServicio;

    public ProductoMVCController(ProductoServicio productoServicio, 
                                CategoriaServicio categoriaServicio,
                                ProveedorServicio proveedorServicio) {
        this.productoServicio = productoServicio;
        this.categoriaServicio = categoriaServicio;
        this.proveedorServicio = proveedorServicio;
    }

    @GetMapping
    public String listarProductos(
            @RequestParam(required = false) String buscar,
            @RequestParam(required = false) String categoria,
            @RequestParam(required = false) String proveedor,
            Model model) {

        if (buscar != null && !buscar.isBlank()) {
            model.addAttribute("productos", productoServicio.buscarPorNombreParcial(buscar));
            model.addAttribute("buscar", buscar);
        } else if (categoria != null && !categoria.isBlank()) {
            try {
                var cat = categoriaServicio.buscarPorNombreCategoria(categoria);
                model.addAttribute("productos", productoServicio.filtrarPorCategoria(cat));
            } catch (Exception e) {
                model.addAttribute("productos", productoServicio.listarTodo());
            }
            model.addAttribute("categoriaFiltro", categoria);
        } else if (proveedor != null && !proveedor.isBlank()) {
            model.addAttribute("productos", productoServicio.filtrarPorNombreProveedor(proveedor));
            model.addAttribute("proveedorFiltro", proveedor);
        } else {
            model.addAttribute("productos", productoServicio.listarTodo());
        }

        model.addAttribute("categorias", categoriaServicio.listarTodo());
        model.addAttribute("proveedores", proveedorServicio.listarTodos());
        return "productos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoProducto(Model model) {
        model.addAttribute("producto", new ProductoDTO());
        model.addAttribute("isNew", true);
        model.addAttribute("categorias", categoriaServicio.listarTodo());
        model.addAttribute("proveedores", proveedorServicio.listarTodos());
        return "productos/formulario";
    }

    @PostMapping("/guardar")
    public String guardarProducto(@Valid ProductoDTO producto, Model model, RedirectAttributes redirectAttrs) {
        try {
            productoServicio.guardarProducto(producto);
            redirectAttrs.addFlashAttribute("exito", "Producto creado exitosamente.");
            return "redirect:/productos";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("producto", producto);
            model.addAttribute("isNew", true);
            model.addAttribute("categorias", categoriaServicio.listarTodo());
            model.addAttribute("proveedores", proveedorServicio.listarTodos());
            return "productos/formulario";
        }
    }

    @GetMapping("/{id}/editar")
    public String editarProducto(@PathVariable Long id, Model model) {
        model.addAttribute("producto", productoServicio.buscarPorId(id));
        model.addAttribute("categorias", categoriaServicio.listarTodo());
        model.addAttribute("proveedores", proveedorServicio.listarTodos());
        model.addAttribute("isNew", false);
        return "productos/formulario";
    }

    @PostMapping("/{id}/actualizar")
    public String actualizarProducto(@PathVariable Long id, @Valid ProductoDTO producto, Model model, RedirectAttributes redirectAttrs) {
        try {
            productoServicio.editarProducto(id, producto);
            redirectAttrs.addFlashAttribute("exito", "Producto actualizado exitosamente.");
            return "redirect:/productos";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("producto", producto);
            model.addAttribute("isNew", false);
            model.addAttribute("categorias", categoriaServicio.listarTodo());
            model.addAttribute("proveedores", proveedorServicio.listarTodos());
            return "productos/formulario";
        }
    }

    @GetMapping("/{id}/eliminar")
    public String eliminarProducto(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        try {
            productoServicio.eliminar(id);
            redirectAttrs.addFlashAttribute("exito", "Producto eliminado exitosamente.");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("error", "Error al eliminar: " + e.getMessage());
        }
        return "redirect:/productos";
    }
}
