package com.mipagina.primeraApi.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import java.util.HashMap;
import java.util.Map;

/**
 * Controlador que actúa como proxy hacia el Servicio de Reportes (Máquina 3).
 *
 * Expone endpoints MVC en /reportes/** que llaman internamente a la API Python
 * en REPORT_SERVICE_URL (variable de entorno configurada en docker-compose).
 */
@Controller
@RequestMapping("/reportes")
public class ReporteController {

    @Value("${report.service.url:http://localhost:8081}")
    private String reportServiceUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    // ─────────────────────────────────────────────────────
    // DASHBOARD de reportes (vista HTML)
    // ─────────────────────────────────────────────────────

    @GetMapping
    public String dashboardReportes(Model model) {
        model.addAttribute("reportServiceUrl", reportServiceUrl);
        return "reportes/dashboard";
    }

    // ─────────────────────────────────────────────────────
    // REPORTE 1: Productos con stock bajo
    // GET /reportes/stock-bajo
    // ─────────────────────────────────────────────────────

    @GetMapping("/stock-bajo")
    @ResponseBody
    public ResponseEntity<Object> stockBajo() {
        try {
            Object resultado = restTemplate.getForObject(
                reportServiceUrl + "/reportes/stock-bajo", Object.class);
            return ResponseEntity.ok(resultado);
        } catch (RestClientException e) {
            return ResponseEntity.status(503).body(errorResponse("stock-bajo", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────
    // REPORTE 2: Top 10 productos más movidos por rango de fechas
    // GET /reportes/mas-movidos?fecha_inicio=YYYY-MM-DD&fecha_fin=YYYY-MM-DD
    // ─────────────────────────────────────────────────────

    @GetMapping("/mas-movidos")
    @ResponseBody
    public ResponseEntity<Object> masMovidos(
            @RequestParam String fecha_inicio,
            @RequestParam String fecha_fin) {
        try {
            String url = reportServiceUrl + "/reportes/mas-movidos"
                       + "?fecha_inicio=" + fecha_inicio
                       + "&fecha_fin=" + fecha_fin;
            Object resultado = restTemplate.getForObject(url, Object.class);
            return ResponseEntity.ok(resultado);
        } catch (RestClientException e) {
            return ResponseEntity.status(503).body(errorResponse("mas-movidos", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────
    // REPORTE 3: Valor total del inventario por categoría
    // GET /reportes/valor-inventario
    // ─────────────────────────────────────────────────────

    @GetMapping("/valor-inventario")
    @ResponseBody
    public ResponseEntity<Object> valorInventario() {
        try {
            Object resultado = restTemplate.getForObject(
                reportServiceUrl + "/reportes/valor-inventario", Object.class);
            return ResponseEntity.ok(resultado);
        } catch (RestClientException e) {
            return ResponseEntity.status(503).body(errorResponse("valor-inventario", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────
    // REPORTE 4: Movimientos por rango de fechas
    // GET /reportes/movimientos?fecha_inicio=&fecha_fin=&tipo= (opcional: ENTRADA|SALIDA)
    // ─────────────────────────────────────────────────────

    @GetMapping("/movimientos")
    @ResponseBody
    public ResponseEntity<Object> movimientos(
            @RequestParam String fecha_inicio,
            @RequestParam String fecha_fin,
            @RequestParam(required = false) String tipo) {
        try {
            String url = reportServiceUrl + "/reportes/movimientos"
                       + "?fecha_inicio=" + fecha_inicio
                       + "&fecha_fin=" + fecha_fin
                       + (tipo != null && !tipo.isBlank() ? "&tipo=" + tipo.toUpperCase() : "");
            Object resultado = restTemplate.getForObject(url, Object.class);
            return ResponseEntity.ok(resultado);
        } catch (RestClientException e) {
            return ResponseEntity.status(503).body(errorResponse("movimientos", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────
    // REPORTE 5: Resumen por proveedor
    // GET /reportes/resumen-proveedor
    // ─────────────────────────────────────────────────────

    @GetMapping("/resumen-proveedor")
    @ResponseBody
    public ResponseEntity<Object> resumenProveedor() {
        try {
            Object resultado = restTemplate.getForObject(
                reportServiceUrl + "/reportes/resumen-proveedor", Object.class);
            return ResponseEntity.ok(resultado);
        } catch (RestClientException e) {
            return ResponseEntity.status(503).body(errorResponse("resumen-proveedor", e.getMessage()));
        }
    }

    // ─────────────────────────────────────────────────────
    // HEALTH del servicio de reportes (proxy)
    // GET /reportes/health
    // ─────────────────────────────────────────────────────

    @GetMapping("/health")
    @ResponseBody
    public ResponseEntity<Object> health() {
        try {
            Object resultado = restTemplate.getForObject(
                reportServiceUrl + "/health", Object.class);
            return ResponseEntity.ok(resultado);
        } catch (RestClientException e) {
            Map<String, String> err = new HashMap<>();
            err.put("status", "error");
            err.put("mensaje", "Servicio de reportes no disponible: " + e.getMessage());
            return ResponseEntity.status(503).body(err);
        }
    }

    // ─────────────────────────────────────────────────────
    // Helper: respuesta de error uniforme
    // ─────────────────────────────────────────────────────

    private Map<String, String> errorResponse(String reporte, String detalle) {
        Map<String, String> err = new HashMap<>();
        err.put("error", "Servicio de reportes no disponible");
        err.put("reporte", reporte);
        err.put("detalle", detalle);
        return err;
    }
}
