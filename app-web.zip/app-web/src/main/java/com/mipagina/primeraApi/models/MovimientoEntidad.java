package com.mipagina.primeraApi.models;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity(name = "movimientos")
@Table(name = "movimientos")
public class MovimientoEntidad {
    
    public enum TipoMovimiento {
        ENTRADA, SALIDA
    }

    public MovimientoEntidad() {}

    public MovimientoEntidad(ProductoEntidad producto, Integer cantidad, TipoMovimiento tipo, 
                             ProveedorEntidad proveedor, String motivo, String observacion) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.tipo = tipo;
        this.fecha = LocalDateTime.now();
        this.proveedor = proveedor;
        this.motivo = motivo;
        this.observacion = observacion;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "producto_id", nullable = false)
    @NotNull(message = "El producto es obligatorio.")
    private ProductoEntidad producto;

    @Column(nullable = false)
    @NotNull(message = "La cantidad es obligatoria.")
    @Positive(message = "La cantidad debe ser positiva.")
    private Integer cantidad;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    @NotNull(message = "El tipo de movimiento es obligatorio.")
    private TipoMovimiento tipo;

    @Column(nullable = false)
    private LocalDateTime fecha;

    @ManyToOne
    @JoinColumn(name = "proveedor_id")
    private ProveedorEntidad proveedor;

    @Column(length = 100)
    private String motivo;

    @Column(length = 255)
    private String observacion;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ProductoEntidad getProducto() {
        return producto;
    }

    public void setProducto(ProductoEntidad producto) {
        this.producto = producto;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public TipoMovimiento getTipo() {
        return tipo;
    }

    public void setTipo(TipoMovimiento tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public ProveedorEntidad getProveedor() {
        return proveedor;
    }

    public void setProveedor(ProveedorEntidad proveedor) {
        this.proveedor = proveedor;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }
}