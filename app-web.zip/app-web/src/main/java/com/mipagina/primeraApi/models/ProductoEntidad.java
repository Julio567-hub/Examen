package com.mipagina.primeraApi.models;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;  
import jakarta.validation.constraints.Positive; 

@Entity(name = "productos")
@Table(name = "productos")
public class ProductoEntidad {

    public ProductoEntidad() {}

    public ProductoEntidad(Long id, String nombre, CategoriaEntidad categoria, Float precio, ProveedorEntidad proveedor) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.proveedor = proveedor;
    }

    public ProductoEntidad(String nombre, CategoriaEntidad categoria, Float precio, ProveedorEntidad proveedor) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.proveedor = proveedor;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "El nombre es obligatorio.")
    private String nombre;

    @Column(length = 500)
    private String descripcion;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "categoria_id", referencedColumnName = "id")
    @JsonBackReference(value = "categoria_referencia")
    private CategoriaEntidad categoria;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "proveedor_id", referencedColumnName = "id")
    @JsonBackReference(value = "proveedor_referencia")
    private ProveedorEntidad proveedor;

    @Column(nullable = false)
    @NotNull(message = "El precio es obligatorio.")
    @Positive(message = "El número ingresado no puede ser 0 o menor.")
    private Float precio;

    @Column(nullable = false)
    private Integer stockActual = 0;

    @Column(nullable = false)
    private Integer stockMinimo = 5;

    //Getters y Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public CategoriaEntidad getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaEntidad categoria) {
        this.categoria = categoria;
    }

    public ProveedorEntidad getProveedor() {
        return proveedor;
    }

    public void setProveedor(ProveedorEntidad proveedor) {
        this.proveedor = proveedor;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public Integer getStockActual() {
        return stockActual;
    }

    public void setStockActual(Integer stockActual) {
        this.stockActual = stockActual;
    }

    public Integer getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(Integer stockMinimo) {
        this.stockMinimo = stockMinimo;
    }
}