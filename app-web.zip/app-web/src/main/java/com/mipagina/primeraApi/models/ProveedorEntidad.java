package com.mipagina.primeraApi.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity(name = "proveedores")
@Table(name = "proveedores")
public class ProveedorEntidad {
    
    public ProveedorEntidad() {}

    public ProveedorEntidad(String nombre, String contacto, String telefono, String email, String direccion) {
        this.nombre = nombre;
        this.contacto = contacto;
        this.telefono = telefono;
        this.email = email;
        this.direccion = direccion;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    @NotBlank(message = "El nombre del proveedor es obligatorio.")
    private String nombre;

    @Column(length = 100)
    private String contacto;

    @Column(length = 20)
    @Pattern(regexp = "^[0-9+\\s-]+$", message = "Formato de teléfono inválido.")
    private String telefono;

    @Column(length = 100, unique = true)
    @Email(message = "Debe proporcionar un email válido.")
    private String email;

    @Column(length = 255)
    private String direccion;

    @OneToMany(mappedBy = "proveedor")
    @JsonManagedReference(value = "proveedor_referencia")
    private List<ProductoEntidad> productos;

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public List<ProductoEntidad> getProductos() {
        return productos;
    }

    public void setProductos(List<ProductoEntidad> productos) {
        this.productos = productos;
    }
}