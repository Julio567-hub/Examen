package com.mipagina.primeraApi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.mipagina.primeraApi.models.CategoriaEntidad;

public interface CategoriaRepositorio extends JpaRepository<CategoriaEntidad, Long> { 

    public Optional<CategoriaEntidad> findByNombre(String nombre);

    

}
