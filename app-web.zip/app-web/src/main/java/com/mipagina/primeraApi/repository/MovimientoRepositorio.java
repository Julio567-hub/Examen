package com.mipagina.primeraApi.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mipagina.primeraApi.models.MovimientoEntidad;
import com.mipagina.primeraApi.models.MovimientoEntidad.TipoMovimiento;
import com.mipagina.primeraApi.models.ProductoEntidad;

public interface MovimientoRepositorio extends JpaRepository<MovimientoEntidad, Long> {

    List<MovimientoEntidad> findByProductoOrderByFechaDesc(ProductoEntidad producto);

    List<MovimientoEntidad> findByTipoOrderByFechaDesc(TipoMovimiento tipo);

    List<MovimientoEntidad> findByFechaBetweenOrderByFechaDesc(LocalDateTime fechaInicio, LocalDateTime fechaFin);

    // Se usa query nativa con CASTs explícitos para que PostgreSQL pueda determinar
    // el tipo de los parámetros nulos correctamente.
    @Query(value = "SELECT * FROM movimientos me " +
                   "WHERE (CAST(:fechaInicio AS timestamp) IS NULL OR me.fecha >= CAST(:fechaInicio AS timestamp)) " +
                   "AND (CAST(:fechaFin AS timestamp) IS NULL OR me.fecha <= CAST(:fechaFin AS timestamp)) " +
                   "AND (CAST(:tipo AS text) IS NULL OR me.tipo = CAST(:tipo AS text)) " +
                   "AND (:productoId IS NULL OR me.producto_id = :productoId) " +
                   "ORDER BY me.fecha DESC",
           nativeQuery = true)
    List<MovimientoEntidad> filtrarMovimientos(
            @Param("fechaInicio") LocalDateTime fechaInicio,
            @Param("fechaFin") LocalDateTime fechaFin,
            @Param("tipo") String tipo,
            @Param("productoId") Long productoId);
}
