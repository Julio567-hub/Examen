package com.mipagina.primeraApi.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mipagina.primeraApi.DTO.ProductoDTO;
import com.mipagina.primeraApi.exceptions.DuplicatedDataException;
import com.mipagina.primeraApi.exceptions.ResourceNotFoundException;
import com.mipagina.primeraApi.models.CategoriaEntidad;
import com.mipagina.primeraApi.models.ProductoEntidad;
import com.mipagina.primeraApi.models.ProveedorEntidad;
import com.mipagina.primeraApi.repository.CategoriaRepositorio;
import com.mipagina.primeraApi.repository.ProductoRepositorio;
import com.mipagina.primeraApi.repository.ProveedorRepositorio;

@Service
public class ProductoServicio {

    final private ProductoRepositorio productoRepositorio;
    final private CategoriaRepositorio categoriaRepositorio;
    final private ProveedorRepositorio proveedorRepositorio;

    public ProductoServicio(ProductoRepositorio productoRepositorio, 
                           CategoriaRepositorio categoriaRepositorio,
                           ProveedorRepositorio proveedorRepositorio) {
        this.productoRepositorio = productoRepositorio;
        this.categoriaRepositorio = categoriaRepositorio;
        this.proveedorRepositorio = proveedorRepositorio;
    }

    public List<ProductoEntidad> listarTodo() {
        return productoRepositorio.findAll();
    }

    public ProductoEntidad buscarPorId(Long id) {
        Optional<ProductoEntidad> resultado = productoRepositorio.findById(id);

        if (resultado.isEmpty()) {
            throw new ResourceNotFoundException("El ID no existe.");
        }
        return resultado.get();
    }

    public ProductoEntidad buscarPorNombre(String nombre) {
        Optional<ProductoEntidad> resultado = productoRepositorio.findByNombre(nombre);

        if (resultado.isEmpty()) {
            throw new ResourceNotFoundException("El nombre no existe.");
        }
        return resultado.get();
    }

    public ProductoEntidad guardarProducto(ProductoDTO atributos) {
        
        if (productoRepositorio.findByNombre(atributos.getNombre()).isPresent()) {
            throw new DuplicatedDataException("El nombre ingresado ya existe. Para realizarle cambios, edite ese producto.");
        }

        Optional<CategoriaEntidad> categoria = categoriaRepositorio.findByNombre(atributos.getCategoria());
        if (categoria.isEmpty()) {
            throw new ResourceNotFoundException("La categoría ingresada no existe.");
        }

        Optional<ProveedorEntidad> proveedor = proveedorRepositorio.findByNombre(atributos.getProveedor());
        if (proveedor.isEmpty()) {
            throw new ResourceNotFoundException("El proveedor ingresado no existe.");
        }

        CategoriaEntidad categoriaFinal = categoria.get();
        ProveedorEntidad proveedorFinal = proveedor.get();

        ProductoEntidad nuevoProducto = new ProductoEntidad(
            atributos.getNombre(), 
            categoriaFinal, 
            atributos.getPrecio(),
            proveedorFinal
        );
        nuevoProducto.setDescripcion(atributos.getDescripcion());
        nuevoProducto.setStockActual(atributos.getStockActual());
        nuevoProducto.setStockMinimo(atributos.getStockMinimo());
        return productoRepositorio.save(nuevoProducto);
    }

    public ProductoEntidad editarProducto(Long id, ProductoDTO atributos) {
        Optional<ProductoEntidad> producto = productoRepositorio.findById(id);
        if (producto.isEmpty()) {
            throw new ResourceNotFoundException("El ID del producto ingresado no existe.");
        }

        ProductoEntidad productoFinal = producto.get();

        Optional<CategoriaEntidad> categoria = categoriaRepositorio.findByNombre(atributos.getCategoria());
        if (categoria.isEmpty()) {
            throw new ResourceNotFoundException("La categoría ingresada no existe.");
        }

        Optional<ProveedorEntidad> proveedor = proveedorRepositorio.findByNombre(atributos.getProveedor());
        if (proveedor.isEmpty()) {
            throw new ResourceNotFoundException("El proveedor ingresado no existe.");
        }

        CategoriaEntidad categoriaFinal = categoria.get();
        ProveedorEntidad proveedorFinal = proveedor.get();

        productoFinal.setNombre(atributos.getNombre());
        productoFinal.setDescripcion(atributos.getDescripcion());
        productoFinal.setCategoria(categoriaFinal);
        productoFinal.setProveedor(proveedorFinal);
        productoFinal.setPrecio(atributos.getPrecio());
        productoFinal.setStockActual(atributos.getStockActual());
        productoFinal.setStockMinimo(atributos.getStockMinimo());

        return productoRepositorio.save(productoFinal); 
    }

    public String eliminar(Long id) {
        Optional<ProductoEntidad> producto = productoRepositorio.findById(id);

        if (producto.isEmpty()) {
            throw new ResourceNotFoundException("El ID a eliminar no existe.");
        }

        ProductoEntidad productoFinal = producto.get();
        productoRepositorio.delete(productoFinal); 

        return "El producto ha sido eliminado con éxito.";
    }

    public List<ProductoEntidad> porPrecioMayorA(Float precio) {
        return productoRepositorio.precioMayorA(precio);
    }

    public List<ProductoEntidad> porRangoDePrecio(Float desde, Float hasta) {
        return productoRepositorio.precioRango(desde, hasta);
    }

    public List<ProductoEntidad> filtrarPorCategoria(CategoriaEntidad categoria) {
        return productoRepositorio.filtrarPorCategoria(categoria);
    }

    public List<ProductoEntidad> filtrarPorProveedor(ProveedorEntidad proveedor) {
        return productoRepositorio.filtrarPorProveedor(proveedor);
    }

    public List<ProductoEntidad> filtrarPorNombreProveedor(String nombreProveedor) {
        return productoRepositorio.filtrarPorNombreProveedor(nombreProveedor);
    }

    public List<ProductoEntidad> buscarPorNombreParcial(String nombre) {
        return productoRepositorio.buscarPorNombreParcial(nombre);
    }

    public List<ProductoEntidad> productosConStockBajo() {
        return productoRepositorio.productosConStockBajo();
    }
}
