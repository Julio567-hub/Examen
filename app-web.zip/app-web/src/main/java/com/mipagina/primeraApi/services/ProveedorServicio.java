package com.mipagina.primeraApi.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mipagina.primeraApi.DTO.ProveedorDTO;
import com.mipagina.primeraApi.exceptions.DuplicatedDataException;
import com.mipagina.primeraApi.exceptions.ResourceNotFoundException;
import com.mipagina.primeraApi.models.ProveedorEntidad;
import com.mipagina.primeraApi.repository.ProveedorRepositorio;

@Service
public class ProveedorServicio {
    
    private final ProveedorRepositorio proveedorRepositorio;

    public ProveedorServicio(ProveedorRepositorio proveedorRepositorio) {
        this.proveedorRepositorio = proveedorRepositorio;
    }

    public List<ProveedorEntidad> listarTodos() {
        return proveedorRepositorio.findAll();
    }

    public ProveedorEntidad buscarPorId(Long id) {
        return proveedorRepositorio.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con ID: " + id));
    }

    public ProveedorEntidad buscarPorNombre(String nombre) {
        return proveedorRepositorio.findByNombre(nombre)
            .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con nombre: " + nombre));
    }

    public ProveedorEntidad guardarProveedor(ProveedorDTO proveedorDTO) {
        // Validar nombre único
        if (proveedorRepositorio.findByNombre(proveedorDTO.getNombre()).isPresent()) {
            throw new DuplicatedDataException("Ya existe un proveedor con el nombre: " + proveedorDTO.getNombre());
        }

        // Validar email único si viene
        if (proveedorDTO.getEmail() != null && !proveedorDTO.getEmail().isEmpty()) {
            if (proveedorRepositorio.findByEmail(proveedorDTO.getEmail()).isPresent()) {
                throw new DuplicatedDataException("Ya existe un proveedor con el email: " + proveedorDTO.getEmail());
            }
        }

        ProveedorEntidad proveedor = new ProveedorEntidad(
            proveedorDTO.getNombre(),
            proveedorDTO.getContacto(),
            proveedorDTO.getTelefono(),
            proveedorDTO.getEmail(),
            proveedorDTO.getDireccion()
        );

        return proveedorRepositorio.save(proveedor);
    }

    public ProveedorEntidad editarProveedor(Long id, ProveedorDTO proveedorDTO) {
        ProveedorEntidad proveedor = buscarPorId(id);

        // Verificar si el nuevo nombre ya existe (y no es el mismo proveedor)
        if (!proveedor.getNombre().equals(proveedorDTO.getNombre())) {
            if (proveedorRepositorio.findByNombre(proveedorDTO.getNombre()).isPresent()) {
                throw new DuplicatedDataException("Ya existe un proveedor con el nombre: " + proveedorDTO.getNombre());
            }
        }

        // Verificar si el nuevo email ya existe (y no es el mismo proveedor)
        if (proveedorDTO.getEmail() != null && !proveedorDTO.getEmail().isEmpty() &&
            !proveedorDTO.getEmail().equals(proveedor.getEmail())) {
            if (proveedorRepositorio.findByEmail(proveedorDTO.getEmail()).isPresent()) {
                throw new DuplicatedDataException("Ya existe un proveedor con el email: " + proveedorDTO.getEmail());
            }
        }

        proveedor.setNombre(proveedorDTO.getNombre());
        proveedor.setContacto(proveedorDTO.getContacto());
        proveedor.setTelefono(proveedorDTO.getTelefono());
        proveedor.setEmail(proveedorDTO.getEmail());
        proveedor.setDireccion(proveedorDTO.getDireccion());

        return proveedorRepositorio.save(proveedor);
    }

    public String eliminarProveedor(Long id) {
        ProveedorEntidad proveedor = buscarPorId(id);
        
        // Verificar si tiene productos asociados
        if (proveedor.getProductos() != null && !proveedor.getProductos().isEmpty()) {
            throw new RuntimeException("No se puede eliminar el proveedor porque tiene productos asociados.");
        }

        proveedorRepositorio.delete(proveedor);
        return "Proveedor eliminado con éxito.";
    }
}