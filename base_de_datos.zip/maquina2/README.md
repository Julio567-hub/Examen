# Máquina 2 — Base de Datos (PostgreSQL)

## Estructura
```
maquina2/
├── docker-compose.yml       ← PostgreSQL + pgAdmin
├── init.sql                 ← Esquema completo + datos semilla
├── pgadmin-servers.json     ← Conexión preconfigurada en pgAdmin
├── .env.example             ← Variables de entorno (copiar como .env)
└── README.md
```

## Despliegue

```bash
# 1. Copiar variables de entorno
cp .env.example .env

# 2. (Opcional) Editar .env con contraseñas propias
#    Asegúrate de usar la misma contraseña que configures en Máquina 1 y 3

# 3. Levantar los servicios
docker compose up -d --build

# 4. Verificar que la BD está lista
docker compose ps
docker exec inventario-db pg_isready -U postgres -d Comida
```

## Servicios expuestos

| Servicio    | Puerto | URL / Descripción                         |
|-------------|--------|-------------------------------------------|
| PostgreSQL  | 5432   | Conexión desde Máquinas 1 y 3             |
| pgAdmin     | 5050   | http://IP_MAQUINA2:5050 (admin web)       |

## Acceder a pgAdmin

1. Abrir `http://IP_MAQUINA2:5050` en el navegador
2. Email: `admin@inventario.com` / Password: `admin123`
3. La conexión a la base de datos ya está preconfigurada

## Conectar desde Máquina 1 (Spring Boot)

En el `application.properties` o `.env` de Máquina 1:
```properties
spring.datasource.url=jdbc:postgresql://IP_MAQUINA2:5432/Comida
spring.datasource.username=postgres
spring.datasource.password=12345
```

## Conectar desde Máquina 3 (Servicio de Reportes)

En el `.env` del servicio Python:
```
DB_HOST=IP_MAQUINA2
DB_PORT=5432
DB_NAME=Comida
DB_USER=postgres
DB_PASSWORD=12345
```

## Datos semilla incluidos

| Tabla        | Registros |
|--------------|-----------|
| categoria    | 5         |
| proveedores  | 5         |
| productos    | 20        |
| movimientos  | 30        |

Los productos incluyen un caso de **stock bajo** (esponjas: stock=3, mínimo=8)
para que la alerta visual de Máquina 1 y el reporte de Máquina 3 funcionen desde el inicio.

## Volúmenes persistentes

Los datos se guardan en volúmenes Docker con nombre:
- `inventario_pg_data` → datos de PostgreSQL
- `inventario_pgadmin_data` → configuración de pgAdmin

Para borrar los datos y empezar desde cero:
```bash
docker compose down -v
docker compose up -d
```

## Reiniciar solo la BD (sin borrar datos)

```bash
docker compose restart postgres
```
