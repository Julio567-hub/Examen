
DROP TABLE IF EXISTS movimientos CASCADE;
DROP TABLE IF EXISTS productos    CASCADE;
DROP TABLE IF EXISTS proveedores  CASCADE;
DROP TABLE IF EXISTS categoria    CASCADE;

CREATE TABLE categoria (
    id BIGSERIAL PRIMARY KEY,
    nombre VARCHAR(20) NOT NULL,
    descripcion VARCHAR(200)
);

CREATE TABLE proveedores (
    id BIGSERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    contacto VARCHAR(100),
    telefono VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    direccion VARCHAR(255)
);

CREATE TABLE productos (
    id BIGSERIAL PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    descripcion VARCHAR(500),
    precio FLOAT NOT NULL,
    stock_actual INTEGER NOT NULL DEFAULT 0,
    stock_minimo INTEGER NOT NULL DEFAULT 5,
    categoria_id BIGINT REFERENCES categoria(id),
    proveedor_id BIGINT REFERENCES proveedores(id)
);

CREATE TABLE movimientos (
    id           BIGSERIAL PRIMARY KEY,
    producto_id  BIGINT         NOT NULL REFERENCES productos(id),
    cantidad     INTEGER        NOT NULL,
    tipo         VARCHAR(10)    NOT NULL CHECK (tipo IN ('ENTRADA', 'SALIDA')),
    fecha        TIMESTAMP      NOT NULL DEFAULT NOW(),
    proveedor_id BIGINT         REFERENCES proveedores(id),
    motivo       VARCHAR(100),
    observacion  VARCHAR(255)
);


-- 3. Inserción de Categorías
INSERT INTO categoria (nombre, descripcion) VALUES
('Electrónica', 'Dispositivos electrónicos y accesorios'),
('Alimentos',   'Productos alimenticios y bebidas'),
('Ropa',         'Prendas de vestir y calzado'),
('Herramientas', 'Herramientas manuales y eléctricas'),
('Limpieza',     'Productos de higiene y hogar');

-- 4. Inserción de Proveedores
INSERT INTO proveedores (nombre, contacto, email) VALUES
('Tech Solutions', 'Juan García', 'contacto@techsolutions.com'),
('Distribuciones Globales', 'María López', 'info@distribuciones.com'),
('Importaciones Express', 'Carlos Rodríguez', 'ventas@importaciones.com'),
('Alimentos del Sur', 'Ana Fernández', 'pedidos@alimentosdelsur.com'),
('HerraMax', 'Roberto Sánchez', 'contacto@herramax.com.ar');

-- 5. Inserción de Productos 

INSERT INTO productos (nombre, descripcion, precio, stock_actual, stock_minimo, categoria_id, proveedor_id) VALUES
-- Electrónica
('Notebook Lenovo IdeaPad', 'Laptop 15.6" i5', 749.99, 12, 5, (SELECT id FROM categoria WHERE nombre='Electrónica'), (SELECT id FROM proveedores WHERE nombre='Tech Solutions')),
('Monitor Samsung 24"', 'Monitor Full HD', 199.50, 8, 3, (SELECT id FROM categoria WHERE nombre='Electrónica'), (SELECT id FROM proveedores WHERE nombre='Tech Solutions')),
('Teclado Mecánico Redragon', 'Teclado gaming RGB', 59.90, 20, 5, (SELECT id FROM categoria WHERE nombre='Electrónica'), (SELECT id FROM proveedores WHERE nombre='Importaciones Express')),
('Mouse Logitech MX Master', 'Mouse ergonómico', 89.00, 15, 5, (SELECT id FROM categoria WHERE nombre='Electrónica'), (SELECT id FROM proveedores WHERE nombre='Tech Solutions')),
('Auriculares Sony WH-1000XM5', 'Noise cancelling', 299.00, 6, 3, (SELECT id FROM categoria WHERE nombre='Electrónica'), (SELECT id FROM proveedores WHERE nombre='Importaciones Express')),

-- Alimentos
('Arroz Largo Fino 1kg', 'Bolsa 1kg', 1.80, 150, 30, (SELECT id FROM categoria WHERE nombre='Alimentos'), (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur')),
('Aceite Girasol 900ml', 'Botella 900ml', 2.50, 80, 20, (SELECT id FROM categoria WHERE nombre='Alimentos'), (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur')),
('Yerba Mate 500g', 'Paquete 500g', 3.20, 200, 50, (SELECT id FROM categoria WHERE nombre='Alimentos'), (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur')),
('Fideos Spaghetti 500g', 'Pasta de sémola', 1.40, 120, 30, (SELECT id FROM categoria WHERE nombre='Alimentos'), (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales')),
('Galletitas Rellenas x36', 'Pack familiar', 4.90, 60, 15, (SELECT id FROM categoria WHERE nombre='Alimentos'), (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales')),

-- Ropa
('Remera Algodón Talle M', '100% Algodón', 8.50, 45, 10, (SELECT id FROM categoria WHERE nombre='Ropa'), (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales')),
('Jean Slim Talle 32', 'Corte Slim Fit', 29.90, 30, 8, (SELECT id FROM categoria WHERE nombre='Ropa'), (SELECT id FROM proveedores WHERE nombre='Importaciones Express')),
('Campera Impermeable', 'Con capucha', 54.00, 18, 5, (SELECT id FROM categoria WHERE nombre='Ropa'), (SELECT id FROM proveedores WHERE nombre='Importaciones Express')),
('Medias Pack x6', 'Tobilleras', 7.20, 80, 20, (SELECT id FROM categoria WHERE nombre='Ropa'), (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales')),
('Zapatillas Running', 'Suela EVA', 65.00, 22, 6, (SELECT id FROM categoria WHERE nombre='Ropa'), (SELECT id FROM proveedores WHERE nombre='Importaciones Express')),

-- Herramientas
('Taladro Eléctrico 500W', 'Percutor', 48.90, 10, 3, (SELECT id FROM categoria WHERE nombre='Herramientas'), (SELECT id FROM proveedores WHERE nombre='HerraMax')),
('Set Destornilladores x12', 'Phillips y Planos', 14.50, 35, 8, (SELECT id FROM categoria WHERE nombre='Herramientas'), (SELECT id FROM proveedores WHERE nombre='HerraMax')),

-- Limpieza
('Detergente Líquido 1L', 'Aroma Limón', 2.80, 100, 25, (SELECT id FROM categoria WHERE nombre='Limpieza'), (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales')),
('Lavandina Concentrada 1L', 'Cloro activo', 1.90, 90, 25, (SELECT id FROM categoria WHERE nombre='Limpieza'), (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur')),
('Esponja Doble Uso x3', 'Verde y amarillo', 3.10, 3, 8, (SELECT id FROM categoria WHERE nombre='Limpieza'), (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales'));

-- =============================================================
-- 4. MOVIMIENTOS (30)
-- =============================================================
INSERT INTO movimientos (producto_id, cantidad, tipo, fecha, proveedor_id, motivo, observacion) VALUES
-- 10 Entradas iniciales
((SELECT id FROM productos WHERE nombre='Notebook Lenovo IdeaPad'), 15, 'ENTRADA', NOW() - INTERVAL '60 days', (SELECT id FROM proveedores WHERE nombre='Tech Solutions'), 'Carga inicial', 'Stock apertura'),
((SELECT id FROM productos WHERE nombre='Monitor Samsung 24"'), 10, 'ENTRADA', NOW() - INTERVAL '60 days', (SELECT id FROM proveedores WHERE nombre='Tech Solutions'), 'Carga inicial', 'Stock apertura'),
((SELECT id FROM productos WHERE nombre='Teclado Mecánico Redragon'), 25, 'ENTRADA', NOW() - INTERVAL '55 days', (SELECT id FROM proveedores WHERE nombre='Importaciones Express'), 'Compra', 'Reposición mensual'),
((SELECT id FROM productos WHERE nombre='Arroz Largo Fino 1kg'), 200, 'ENTRADA', NOW() - INTERVAL '55 days', (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur'), 'Compra', 'Lote mayorista'),
((SELECT id FROM productos WHERE nombre='Aceite Girasol 900ml'), 100, 'ENTRADA', NOW() - INTERVAL '55 days', (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur'), 'Compra', 'Lote mayorista'),
((SELECT id FROM productos WHERE nombre='Yerba Mate 500g'), 250, 'ENTRADA', NOW() - INTERVAL '50 days', (SELECT id FROM proveedores WHERE nombre='Alimentos del Sur'), 'Compra', 'Stock crítico'),
((SELECT id FROM productos WHERE nombre='Remera Algodón Talle M'), 60, 'ENTRADA', NOW() - INTERVAL '50 days', (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales'), 'Compra', 'Temporada'),
((SELECT id FROM productos WHERE nombre='Jean Slim Talle 32'), 40, 'ENTRADA', NOW() - INTERVAL '48 days', (SELECT id FROM proveedores WHERE nombre='Importaciones Express'), 'Compra', 'Temporada'),
((SELECT id FROM productos WHERE nombre='Detergente Líquido 1L'), 130, 'ENTRADA', NOW() - INTERVAL '45 days', (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales'), 'Carga inicial', 'Higiene'),
((SELECT id FROM productos WHERE nombre='Esponja Doble Uso x3'), 10, 'ENTRADA', NOW() - INTERVAL '45 days', (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales'), 'Carga inicial', 'Higiene'),

-- 10 Salidas (Ventas)
((SELECT id FROM productos WHERE nombre='Notebook Lenovo IdeaPad'), 3, 'SALIDA', NOW() - INTERVAL '40 days', NULL, 'Venta', 'Cliente minorista'),
((SELECT id FROM productos WHERE nombre='Arroz Largo Fino 1kg'), 50, 'SALIDA', NOW() - INTERVAL '38 days', NULL, 'Venta', 'Venta diaria'),
((SELECT id FROM productos WHERE nombre='Yerba Mate 500g'), 30, 'SALIDA', NOW() - INTERVAL '35 days', NULL, 'Venta', 'Venta diaria'),
((SELECT id FROM productos WHERE nombre='Remera Algodón Talle M'), 15, 'SALIDA', NOW() - INTERVAL '33 days', NULL, 'Venta', 'Venta mostrador'),
((SELECT id FROM productos WHERE nombre='Detergente Líquido 1L'), 30, 'SALIDA', NOW() - INTERVAL '30 days', NULL, 'Venta', 'Venta local'),
((SELECT id FROM productos WHERE nombre='Teclado Mecánico Redragon'), 5, 'SALIDA', NOW() - INTERVAL '28 days', NULL, 'Venta', 'Venta online'),
((SELECT id FROM productos WHERE nombre='Aceite Girasol 900ml'), 20, 'SALIDA', NOW() - INTERVAL '25 days', NULL, 'Venta', 'Venta diaria'),
((SELECT id FROM productos WHERE nombre='Jean Slim Talle 32'), 10, 'SALIDA', NOW() - INTERVAL '22 days', NULL, 'Venta', 'Venta local'),
((SELECT id FROM productos WHERE nombre='Monitor Samsung 24"'), 2, 'SALIDA', NOW() - INTERVAL '20 days', NULL, 'Venta', 'Cliente empresa'),
((SELECT id FROM productos WHERE nombre='Zapatillas Running'), 5, 'SALIDA', NOW() - INTERVAL '18 days', NULL, 'Venta', 'Venta online'),

-- 10 Movimientos mixtos (Reposición y últimas ventas)
((SELECT id FROM productos WHERE nombre='Mouse Logitech MX Master'), 20, 'ENTRADA', NOW() - INTERVAL '15 days', (SELECT id FROM proveedores WHERE nombre='Tech Solutions'), 'Reposición', 'Stock mínimo'),
((SELECT id FROM productos WHERE nombre='Auriculares Sony WH-1000XM5'), 8, 'ENTRADA', NOW() - INTERVAL '14 days', (SELECT id FROM proveedores WHERE nombre='Importaciones Express'), 'Reposición', 'Stock mínimo'),
((SELECT id FROM productos WHERE nombre='Fideos Spaghetti 500g'), 150, 'ENTRADA', NOW() - INTERVAL '12 days', (SELECT id FROM proveedores WHERE nombre='Distribuciones Globales'), 'Compra', 'Oferta proveedor'),
((SELECT id FROM productos WHERE nombre='Taladro Eléctrico 500W'), 15, 'ENTRADA', NOW() - INTERVAL '10 days', (SELECT id FROM proveedores WHERE nombre='HerraMax'), 'Compra', 'Herramientas'),
((SELECT id FROM productos WHERE nombre='Arroz Largo Fino 1kg'), 30, 'SALIDA', NOW() - INTERVAL '8 days', NULL, 'Venta', 'Venta diaria'),
((SELECT id FROM productos WHERE nombre='Fideos Spaghetti 500g'), 30, 'SALIDA', NOW() - INTERVAL '6 days', NULL, 'Venta', 'Venta diaria'),
((SELECT id FROM productos WHERE nombre='Remera Algodón Talle M'), 8, 'SALIDA', NOW() - INTERVAL '4 days', NULL, 'Venta', 'Venta mostrador'),
((SELECT id FROM productos WHERE nombre='Notebook Lenovo IdeaPad'), 2, 'SALIDA', NOW() - INTERVAL '3 days', NULL, 'Venta', 'Venta online'),
((SELECT id FROM productos WHERE nombre='Esponja Doble Uso x3'), 7, 'SALIDA', NOW() - INTERVAL '2 days', NULL, 'Venta', 'Ajuste de inventario'),
((SELECT id FROM productos WHERE nombre='Lavandina Concentrada 1L'), 10, 'SALIDA', NOW() - INTERVAL '1 day', NULL, 'Venta', 'Venta diaria');