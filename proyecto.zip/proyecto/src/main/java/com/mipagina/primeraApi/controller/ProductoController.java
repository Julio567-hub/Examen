package com.mipagina.primeraApi.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mipagina.primeraApi.DTO.ProductoDTO;
import com.mipagina.primeraApi.models.CategoriaEntidad;
import com.mipagina.primeraApi.models.ProductoEntidad;
import com.mipagina.primeraApi.services.CategoriaServicio;
import com.mipagina.primeraApi.services.ProductoServicio;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/inventario")
public class ProductoController {

    private final CategoriaServicio categoriaServicio;
    
    private final ProductoServicio productoServicio;

    public ProductoController(ProductoServicio productoServicio, CategoriaServicio categoriaServicio) {
        this.productoServicio = productoServicio;
        this.categoriaServicio = categoriaServicio;
    } 

    @GetMapping
    public ResponseEntity<Object> verInventario() {
        return ResponseEntity.ok(productoServicio.listarTodo());
    }

    @GetMapping("/categorias")
    public ResponseEntity<Object> verCategorias() {
        return ResponseEntity.ok(categoriaServicio.listarTodo());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(productoServicio.buscarPorId(id));
    }

    @GetMapping("/categoria/buscar")
    public ResponseEntity<Object> buscarPorNombreCategoria(@RequestParam String categoria) {
        return ResponseEntity.ok(categoriaServicio.buscarPorNombreCategoria(categoria));
    }

    @GetMapping("/producto")
    public ResponseEntity<Object> buscarPorNombre(@RequestParam String nombre) {
        return ResponseEntity.ok(productoServicio.buscarPorNombre(nombre));
    }

    @PostMapping("/guardar/producto")
    public ResponseEntity<Object> guardarProducto(@Valid @RequestBody ProductoDTO producto) {
        return ResponseEntity.ok(productoServicio.guardarProducto(producto));            
    }

    @PostMapping("/guardar/categoria")
    public ResponseEntity<Object> guardarCategoria(@Valid @RequestBody CategoriaEntidad categoria) {
        return ResponseEntity.ok(categoriaServicio.guardarCategoria(categoria));            
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<Object> editarProducto(@PathVariable Long id, @Valid @RequestBody ProductoDTO datosNuevos) {
       return ResponseEntity.ok(productoServicio.editarProducto(id, datosNuevos));            
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminarProducto(@PathVariable Long id) {
        return ResponseEntity.ok(productoServicio.eliminar(id));
    }

    @GetMapping("/filtrar/precio/mayor_a")
    public ResponseEntity<?> filtrarPorPrecioMayorA(@RequestParam Float precio) {
        List<ProductoEntidad> resultado = productoServicio.porPrecioMayorA(precio);

        if (resultado.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay productos con precio mayor al especificado.");
        } else {
            return ResponseEntity.ok(resultado);    
        }
    }

    @GetMapping("/filtrar/precio/rango")
    public ResponseEntity<?> filtrarPorRango(@RequestParam Float desde, @RequestParam Float hasta) {
        List<ProductoEntidad> resultado = productoServicio.porRangoDePrecio(desde, hasta);

        if (resultado.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay productos dentro de ese rango.");
        } else {
            return ResponseEntity.ok(resultado);    
        }
    }

    @GetMapping("/filtrar/categoria")
    public ResponseEntity<?> filtrarPorCategoria(@RequestParam CategoriaEntidad categoria) {
        List<ProductoEntidad> resultado = productoServicio.filtrarPorCategoria(categoria);

        if (resultado.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No hay productos de esa categoría.");
        } else {
            return ResponseEntity.ok(resultado);    
        }
    }

}
