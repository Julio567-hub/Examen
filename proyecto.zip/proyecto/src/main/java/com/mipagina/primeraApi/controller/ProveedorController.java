package com.mipagina.primeraApi.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mipagina.primeraApi.DTO.ProveedorDTO;
import com.mipagina.primeraApi.models.ProveedorEntidad;
import com.mipagina.primeraApi.services.ProveedorServicio;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/inventario/proveedores")
public class ProveedorController {
    
    private final ProveedorServicio proveedorServicio;

    public ProveedorController(ProveedorServicio proveedorServicio) {
        this.proveedorServicio = proveedorServicio;
    }

    @GetMapping
    public ResponseEntity<List<ProveedorEntidad>> listarTodos() {
        return ResponseEntity.ok(proveedorServicio.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProveedorEntidad> buscarPorId(@PathVariable Long id) {
        return ResponseEntity.ok(proveedorServicio.buscarPorId(id));
    }

    @GetMapping("/buscar")
    public ResponseEntity<ProveedorEntidad> buscarPorNombre(@RequestParam String nombre) {
        return ResponseEntity.ok(proveedorServicio.buscarPorNombre(nombre));
    }

    @PostMapping("/guardar")
    public ResponseEntity<ProveedorEntidad> guardarProveedor(@Valid @RequestBody ProveedorDTO proveedorDTO) {
        return ResponseEntity.ok(proveedorServicio.guardarProveedor(proveedorDTO));
    }

    @PutMapping("/editar/{id}")
    public ResponseEntity<ProveedorEntidad> editarProveedor(@PathVariable Long id, @Valid @RequestBody ProveedorDTO proveedorDTO) {
        return ResponseEntity.ok(proveedorServicio.editarProveedor(id, proveedorDTO));
    }

    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<String> eliminarProveedor(@PathVariable Long id) {
        return ResponseEntity.ok(proveedorServicio.eliminarProveedor(id));
    }
}