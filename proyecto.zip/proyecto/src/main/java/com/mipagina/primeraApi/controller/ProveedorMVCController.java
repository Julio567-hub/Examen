package com.mipagina.primeraApi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mipagina.primeraApi.DTO.ProveedorDTO;
import com.mipagina.primeraApi.services.ProductoServicio;
import com.mipagina.primeraApi.services.ProveedorServicio;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/proveedores")
public class ProveedorMVCController {

    private final ProveedorServicio proveedorServicio;
    private final ProductoServicio productoServicio;

    public ProveedorMVCController(ProveedorServicio proveedorServicio, ProductoServicio productoServicio) {
        this.proveedorServicio = proveedorServicio;
        this.productoServicio = productoServicio;
    }

    @GetMapping
    public String listarProveedores(Model model) {
        model.addAttribute("proveedores", proveedorServicio.listarTodos());
        return "proveedores/lista";
    }

    @GetMapping("/nuevo")
    public String nuevoProveedor(Model model) {
        model.addAttribute("proveedor", new ProveedorDTO());
        model.addAttribute("isNew", true);
        return "proveedores/formulario";
    }

    @PostMapping("/guardar")
    public String guardarProveedor(@Valid ProveedorDTO proveedor, Model model, RedirectAttributes redirectAttrs) {
        try {
            proveedorServicio.guardarProveedor(proveedor);
            redirectAttrs.addFlashAttribute("exito", "Proveedor creado exitosamente.");
            return "redirect:/proveedores";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("proveedor", proveedor);
            model.addAttribute("isNew", true);
            return "proveedores/formulario";
        }
    }

    @GetMapping("/{id}/editar")
    public String editarProveedor(@PathVariable Long id, Model model) {
        model.addAttribute("proveedor", proveedorServicio.buscarPorId(id));
        model.addAttribute("isNew", false);
        return "proveedores/formulario";
    }

    @PostMapping("/{id}/actualizar")
    public String actualizarProveedor(@PathVariable Long id, @Valid ProveedorDTO proveedor, Model model, RedirectAttributes redirectAttrs) {
        try {
            proveedorServicio.editarProveedor(id, proveedor);
            redirectAttrs.addFlashAttribute("exito", "Proveedor actualizado exitosamente.");
            return "redirect:/proveedores";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("proveedor", proveedor);
            model.addAttribute("isNew", false);
            return "proveedores/formulario";
        }
    }

    @GetMapping("/{id}/eliminar")
    public String eliminarProveedor(@PathVariable Long id) {
        try {
            proveedorServicio.eliminarProveedor(id);
        } catch (Exception e) {
            // Manejar error
        }
        return "redirect:/proveedores";
    }

    @GetMapping("/{id}/productos")
    public String productosPorProveedor(@PathVariable Long id, Model model) {
        var proveedor = proveedorServicio.buscarPorId(id);
        model.addAttribute("proveedor", proveedor);
        model.addAttribute("productos", productoServicio.filtrarPorProveedor(proveedor));
        return "proveedores/productos";
    }
}
