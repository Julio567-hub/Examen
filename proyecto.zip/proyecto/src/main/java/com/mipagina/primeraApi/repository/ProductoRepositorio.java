package com.mipagina.primeraApi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mipagina.primeraApi.models.CategoriaEntidad;
import com.mipagina.primeraApi.models.ProductoEntidad;
import com.mipagina.primeraApi.models.ProveedorEntidad;

public interface ProductoRepositorio extends JpaRepository<ProductoEntidad, Long> { 
    
    public Optional<ProductoEntidad> findByNombre(String nombre);

    @Query("SELECT p FROM productos p WHERE LOWER(p.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))")
    List<ProductoEntidad> buscarPorNombreParcial(@Param("nombre") String nombre);

    @Query("select p from productos p where p.precio > :preciocomp")
    List<ProductoEntidad> precioMayorA(@Param("preciocomp") Float preciocomp);

    @Query("select p from productos p where p.precio >= :desde and p.precio <= :hasta")
    List<ProductoEntidad> precioRango(@Param("desde") Float desde, @Param("hasta") Float hasta);

    @Query("select p from productos p where p.categoria = :categoria")
    List<ProductoEntidad> filtrarPorCategoria(@Param("categoria") CategoriaEntidad categoria);

    @Query("SELECT p FROM productos p WHERE p.proveedor = :proveedor")
    List<ProductoEntidad> filtrarPorProveedor(@Param("proveedor") ProveedorEntidad proveedor);

    @Query("SELECT p FROM productos p WHERE p.proveedor.nombre LIKE %:nombre%")
    List<ProductoEntidad> filtrarPorNombreProveedor(@Param("nombre") String nombre);

    @Query("SELECT p FROM productos p WHERE p.stockActual <= p.stockMinimo")
    List<ProductoEntidad> productosConStockBajo();
}
