package com.mipagina.primeraApi.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mipagina.primeraApi.models.ProveedorEntidad;

public interface ProveedorRepositorio extends JpaRepository<ProveedorEntidad, Long> {
    
    Optional<ProveedorEntidad> findByNombre(String nombre);
    
    Optional<ProveedorEntidad> findByEmail(String email);
}