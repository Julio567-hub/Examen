package com.mipagina.primeraApi.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.mipagina.primeraApi.exceptions.DuplicatedDataException;
import com.mipagina.primeraApi.exceptions.ResourceNotFoundException;
import com.mipagina.primeraApi.models.CategoriaEntidad;
import com.mipagina.primeraApi.repository.CategoriaRepositorio;

@Service
public class CategoriaServicio {

    final private CategoriaRepositorio categoriaRepositorio;

    public List<CategoriaEntidad> listarTodo() {
        return categoriaRepositorio.findAll();
    }

    public CategoriaServicio(CategoriaRepositorio categoriaRepositorio) {
        this.categoriaRepositorio = categoriaRepositorio;
    }

    public CategoriaEntidad buscarPorNombreCategoria(String nombre) {
        Optional<CategoriaEntidad> resultado = categoriaRepositorio.findByNombre(nombre);

        if (resultado.isEmpty()) {
            throw new ResourceNotFoundException("La categoría no existe.");
        }
        return resultado.get();

    }

    public Optional<CategoriaEntidad> buscarPorId(Long id) {
        return categoriaRepositorio.findById(id);
    }

    public CategoriaEntidad guardarCategoria(CategoriaEntidad atributos) {
        if (categoriaRepositorio.findByNombre(atributos.getNombre()).isPresent()) {
            throw new DuplicatedDataException("El nombre ingresado ya existe. Para realizarle cambios, edite esa categoría.");
        }

        return categoriaRepositorio.save(new CategoriaEntidad(atributos.getNombre(), atributos.getDescripcion()));

    }

    public CategoriaEntidad guardarCategoriaExistente(CategoriaEntidad categoria) {
        return categoriaRepositorio.save(categoria);
    }

    public void eliminarCategoria(CategoriaEntidad categoria) {
        if (categoria.getProductos() != null && !categoria.getProductos().isEmpty()) {
            throw new RuntimeException("No se puede eliminar la categoría porque tiene productos asociados.");
        }
        categoriaRepositorio.delete(categoria);
    }
   
}
