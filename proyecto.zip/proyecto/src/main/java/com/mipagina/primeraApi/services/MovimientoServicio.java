package com.mipagina.primeraApi.services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mipagina.primeraApi.DTO.MovimientoDTO;
import com.mipagina.primeraApi.DTO.MovimientoRespuestaDTO;
import com.mipagina.primeraApi.exceptions.ResourceNotFoundException;
import com.mipagina.primeraApi.models.MovimientoEntidad;
import com.mipagina.primeraApi.models.MovimientoEntidad.TipoMovimiento;
import com.mipagina.primeraApi.models.ProductoEntidad;
import com.mipagina.primeraApi.models.ProveedorEntidad;
import com.mipagina.primeraApi.repository.MovimientoRepositorio;
import com.mipagina.primeraApi.repository.ProductoRepositorio;
import com.mipagina.primeraApi.repository.ProveedorRepositorio;

@Service
public class MovimientoServicio {

    private final MovimientoRepositorio movimientoRepositorio;
    private final ProductoRepositorio productoRepositorio;
    private final ProveedorRepositorio proveedorRepositorio;

    public MovimientoServicio(MovimientoRepositorio movimientoRepositorio,
                              ProductoRepositorio productoRepositorio,
                              ProveedorRepositorio proveedorRepositorio) {
        this.movimientoRepositorio = movimientoRepositorio;
        this.productoRepositorio = productoRepositorio;
        this.proveedorRepositorio = proveedorRepositorio;
    }

    // Convierte una entidad a DTO de respuesta con nombre de producto y proveedor
    private MovimientoRespuestaDTO toDTO(MovimientoEntidad m) {
        return new MovimientoRespuestaDTO(
            m.getId(),
            m.getTipo().name(),
            m.getCantidad(),
            m.getFecha(),
            m.getMotivo(),
            m.getObservacion(),
            m.getProducto() != null ? m.getProducto().getId() : null,
            m.getProducto() != null ? m.getProducto().getNombre() : null,
            m.getProveedor() != null ? m.getProveedor().getId() : null,
            m.getProveedor() != null ? m.getProveedor().getNombre() : null
        );
    }

    public List<MovimientoRespuestaDTO> listarTodos() {
        return movimientoRepositorio.findAll()
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public MovimientoRespuestaDTO buscarPorId(Long id) {
        MovimientoEntidad m = movimientoRepositorio.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Movimiento no encontrado con ID: " + id));
        return toDTO(m);
    }

    @Transactional
    public MovimientoRespuestaDTO registrarMovimiento(MovimientoDTO movimientoDTO) {
        ProductoEntidad producto = productoRepositorio.findById(movimientoDTO.getProductoId())
            .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con ID: " + movimientoDTO.getProductoId()));

        ProveedorEntidad proveedor = null;
        if (movimientoDTO.getProveedorId() != null) {
            proveedor = proveedorRepositorio.findById(movimientoDTO.getProveedorId())
                .orElseThrow(() -> new ResourceNotFoundException("Proveedor no encontrado con ID: " + movimientoDTO.getProveedorId()));
        }

        MovimientoEntidad movimiento = new MovimientoEntidad(
            producto,
            movimientoDTO.getCantidad(),
            movimientoDTO.getTipo(),
            proveedor,
            movimientoDTO.getMotivo(),
            movimientoDTO.getObservacion()
        );

        if (movimientoDTO.getTipo() == TipoMovimiento.ENTRADA) {
            producto.setStockActual(producto.getStockActual() + movimientoDTO.getCantidad());
        } else {
            if (producto.getStockActual() < movimientoDTO.getCantidad()) {
                throw new RuntimeException("Stock insuficiente. Stock actual: " + producto.getStockActual());
            }
            producto.setStockActual(producto.getStockActual() - movimientoDTO.getCantidad());
        }

        productoRepositorio.save(producto);
        return toDTO(movimientoRepositorio.save(movimiento));
    }

    public List<MovimientoRespuestaDTO> filtrarMovimientos(LocalDateTime fechaInicio,
                                                           LocalDateTime fechaFin,
                                                           TipoMovimiento tipo,
                                                           Long productoId) {
        // Convertimos el enum a String (o null) para la query nativa
        String tipoStr = tipo != null ? tipo.name() : null;
        return movimientoRepositorio.filtrarMovimientos(fechaInicio, fechaFin, tipoStr, productoId)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<MovimientoRespuestaDTO> movimientosPorProducto(Long productoId) {
        ProductoEntidad producto = productoRepositorio.findById(productoId)
            .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado con ID: " + productoId));
        return movimientoRepositorio.findByProductoOrderByFechaDesc(producto)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<MovimientoRespuestaDTO> movimientosPorTipo(TipoMovimiento tipo) {
        return movimientoRepositorio.findByTipoOrderByFechaDesc(tipo)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<MovimientoRespuestaDTO> movimientosPorRangoFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        return movimientoRepositorio.findByFechaBetweenOrderByFechaDesc(fechaInicio, fechaFin)
                .stream().map(this::toDTO).collect(Collectors.toList());
    }
}
