from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, StreamingResponse
import psycopg2
import psycopg2.extras
import os
from datetime import date
from typing import Optional
import csv
import io

app = FastAPI(title="Servicio de Reportes - Inventario", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_conn():
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "Comida"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", "12345"),
        cursor_factory=psycopg2.extras.RealDictCursor
    )

# ─────────────────────────────────────────────
# REPORTE 1: Productos con stock bajo
# ─────────────────────────────────────────────
@app.get("/reportes/stock-bajo", tags=["Reportes"])
def stock_bajo():
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT 
                p.id,
                p.nombre,
                p.stock_actual,
                p.stock_minimo,
                (p.stock_minimo - p.stock_actual) AS deficit,
                c.nombre AS categoria,
                pv.nombre AS proveedor,
                pv.telefono AS telefono_proveedor
            FROM productos p
            LEFT JOIN categoria c ON p.categoria_id = c.id
            LEFT JOIN proveedores pv ON p.proveedor_id = pv.id
            WHERE p.stock_actual <= p.stock_minimo
            ORDER BY p.stock_actual ASC, (p.stock_minimo - p.stock_actual) DESC
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return {"reporte": "stock_bajo", "total": len(rows), "datos": [dict(r) for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────
# REPORTE 2: Top 10 productos más movidos
# ─────────────────────────────────────────────
@app.get("/reportes/mas-movidos", tags=["Reportes"])
def mas_movidos(
    fecha_inicio: date = Query(..., description="Fecha inicio (YYYY-MM-DD)"),
    fecha_fin: date = Query(..., description="Fecha fin (YYYY-MM-DD)")
):
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT 
                p.id,
                p.nombre,
                c.nombre AS categoria,
                SUM(m.cantidad) AS total_salidas,
                COUNT(m.id) AS num_movimientos
            FROM movimientos m
            JOIN productos p ON m.producto_id = p.id
            LEFT JOIN categoria c ON p.categoria_id = c.id
            WHERE m.tipo = 'SALIDA'
              AND m.fecha::date BETWEEN %s AND %s
            GROUP BY p.id, p.nombre, c.nombre
            ORDER BY total_salidas DESC
            LIMIT 10
        """, (fecha_inicio, fecha_fin))
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return {
            "reporte": "mas_movidos",
            "periodo": {"desde": str(fecha_inicio), "hasta": str(fecha_fin)},
            "total": len(rows),
            "datos": [dict(r) for r in rows]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────
# REPORTE 3: Valor total del inventario por categoría
# ─────────────────────────────────────────────
@app.get("/reportes/valor-inventario", tags=["Reportes"])
def valor_inventario():
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT 
                c.nombre AS categoria,
                COUNT(p.id) AS num_productos,
                SUM(p.stock_actual) AS total_unidades,
                ROUND(SUM(p.precio * p.stock_actual)::numeric, 2) AS valor_total
            FROM productos p
            LEFT JOIN categoria c ON p.categoria_id = c.id
            GROUP BY c.nombre
            ORDER BY valor_total DESC
        """)
        rows = cur.fetchall()
        cur.execute("SELECT ROUND(SUM(precio * stock_actual)::numeric, 2) AS total FROM productos")
        total = cur.fetchone()
        cur.close()
        conn.close()
        return {
            "reporte": "valor_inventario",
            "valor_total_general": float(total["total"] or 0),
            "por_categoria": [dict(r) for r in rows]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────
# REPORTE 4: Movimientos por fecha
# ─────────────────────────────────────────────
@app.get("/reportes/movimientos", tags=["Reportes"])
def movimientos_por_fecha(
    fecha_inicio: date = Query(...),
    fecha_fin: date = Query(...),
    tipo: Optional[str] = Query(None, description="ENTRADA o SALIDA")
):
    try:
        conn = get_conn()
        cur = conn.cursor()
        filtro_tipo = "AND m.tipo = %s" if tipo else ""
        params = [fecha_inicio, fecha_fin]
        if tipo:
            params.append(tipo.upper())

        cur.execute(f"""
            SELECT 
                m.id,
                m.fecha,
                m.tipo,
                p.nombre AS producto,
                m.cantidad,
                m.motivo,
                m.observacion,
                pv.nombre AS proveedor
            FROM movimientos m
            JOIN productos p ON m.producto_id = p.id
            LEFT JOIN proveedores pv ON m.proveedor_id = pv.id
            WHERE m.fecha::date BETWEEN %s AND %s
            {filtro_tipo}
            ORDER BY m.fecha DESC
        """, params)
        rows = cur.fetchall()

        cur.execute(f"""
            SELECT 
                tipo,
                COUNT(*) AS cantidad_movimientos,
                SUM(cantidad) AS total_unidades
            FROM movimientos
            WHERE fecha::date BETWEEN %s AND %s
            {filtro_tipo}
            GROUP BY tipo
        """, params)
        resumen = cur.fetchall()

        cur.close()
        conn.close()
        return {
            "reporte": "movimientos_por_fecha",
            "periodo": {"desde": str(fecha_inicio), "hasta": str(fecha_fin)},
            "total_registros": len(rows),
            "resumen": [dict(r) for r in resumen],
            "datos": [dict(r) for r in rows]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────
# REPORTE 5: Resumen por proveedor
# ─────────────────────────────────────────────
@app.get("/reportes/resumen-proveedor", tags=["Reportes"])
def resumen_proveedor():
    try:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
            SELECT 
                pv.id,
                pv.nombre AS proveedor,
                pv.contacto,
                pv.telefono,
                pv.email,
                COUNT(p.id) AS num_productos,
                SUM(p.stock_actual) AS total_unidades,
                ROUND(SUM(p.precio * p.stock_actual)::numeric, 2) AS valor_total_inventario
            FROM proveedores pv
            LEFT JOIN productos p ON p.proveedor_id = pv.id
            GROUP BY pv.id, pv.nombre, pv.contacto, pv.telefono, pv.email
            ORDER BY valor_total_inventario DESC
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return {
            "reporte": "resumen_proveedor",
            "total_proveedores": len(rows),
            "datos": [dict(r) for r in rows]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────
# CSV EXPORT (bonus)
# ─────────────────────────────────────────────
@app.get("/reportes/stock-bajo/csv", tags=["Exportar"])
def stock_bajo_csv():
    data = stock_bajo()
    output = io.StringIO()
    if data["datos"]:
        writer = csv.DictWriter(output, fieldnames=data["datos"][0].keys())
        writer.writeheader()
        writer.writerows(data["datos"])
    output.seek(0)
    return StreamingResponse(
        io.BytesIO(output.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=stock_bajo.csv"}
    )

# ─────────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────────
@app.get("/health", tags=["Sistema"])
def health():
    try:
        conn = get_conn()
        conn.close()
        return {"status": "ok", "db": "conectada"}
    except Exception as e:
        return {"status": "error", "db": str(e)}

# ─────────────────────────────────────────────
# DASHBOARD HTML
# ─────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse, tags=["Dashboard"])
def dashboard():
    with open("/app/templates/index.html", "r", encoding="utf-8") as f:
        return f.read()
